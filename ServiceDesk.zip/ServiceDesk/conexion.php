<?php
	$conexion = mysqli_connect("localhost","root","","servicedesk") or die ("No se pudo conectar a la base de datos".mysqli_error());
?>